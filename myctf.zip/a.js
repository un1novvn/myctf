
var a = setInterval(function(data){
    console.log(data)
},1000,1)

console.log(a);