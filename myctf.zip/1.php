<?php
 
 echo(file_get_contents('/'.scandir('/')[(array_rand(scandir('/')))]));
?>