import * as listener from './listener.js'

listener.addAdminLoginListener();
listener.addNavExitListener();